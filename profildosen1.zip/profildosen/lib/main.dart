import 'package:flutter/material.dart';

void main() {
  runApp(const ProfilDosenApp());
}

// =========================================================================
// 1. MODEL DATA
// =========================================================================

class Dosen {
  final String nama;
  final String nidn;
  final String bidangKeahlian;
  final String email;
  // Gunakan assets/images/dosen1.png, dll. Pastikan file ada di folder tersebut.
  final String fotoAsset; 

  const Dosen({
    required this.nama,
    required this.nidn,
    required this.bidangKeahlian,
    required this.email,
    required this.fotoAsset,
  });
}

// Data dummy untuk daftar dosen
const List<Dosen> listDosen = [
  Dosen(
    nama: 'Dr. Rina Puspita Sari, S.Kom., M.T.',
    nidn: '0412038001',
    bidangKeahlian: 'Kecerdasan Buatan & Pembelajaran Mesin',
    email: 'rina.sari@kampus.ac.id',
    fotoAsset: 'assets/images/dosen1.png', 
  ),
  Dosen(
    nama: 'Bambang Sudarsono, Ph.D.',
    nidn: '0405077502',
    bidangKeahlian: 'Rekayasa Perangkat Lunak',
    email: 'bambang.sud@kampus.ac.id',
    fotoAsset: 'assets/images/dosen2.png',
  ),
  Dosen(
    nama: 'Prof. Dr. Ir. Candra Kirana',
    nidn: '0420106503',
    bidangKeahlian: 'Jaringan Komputer & Keamanan Siber',
    email: 'candra.kirana@kampus.ac.id',
    fotoAsset: 'assets/images/dosen3.png', 
  ),
];

// =========================================================================
// 2. WIDGET UTAMA (ROOT)
// =========================================================================

class ProfilDosenApp extends StatelessWidget {
  const ProfilDosenApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi Profil Dosen',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Tema warna biru tua yang menarik dan profesional
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.blueGrey,
          foregroundColor: Colors.white,
        ),
        cardTheme: CardThemeData(
          elevation: 4, // Memberikan bayangan
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      home: const DosenListScreen(), // Halaman 1
    );
  }
}

// =========================================================================
// 3. HALAMAN 1: DAFTAR DOSEN (ListView + Card)
// =========================================================================

class DosenListScreen extends StatelessWidget {
  const DosenListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Profil Dosen'),
        centerTitle: true,
      ),
      backgroundColor: Colors.blueGrey.shade50, // Warna latar belakang halaman 1
      body: SafeArea(
        // ListView.builder untuk menampilkan daftar secara efisien
        child: ListView.builder(
          itemCount: listDosen.length,
          padding: const EdgeInsets.all(12.0),
          itemBuilder: (context, index) {
            final dosen = listDosen[index];
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              // Card sebagai wadah setiap item daftar
              child: Card(
                color: Colors.white,
                child: InkWell(
                  // Menggunakan Navigator untuk pindah ke Halaman Detail
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DosenDetailScreen(dosen: dosen),
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    // Row untuk menata gambar dan teks secara horizontal
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        // Bagian Kiri: Image Dosen
                        ClipOval(
                          child: Image.asset(
                            dosen.fotoAsset,
                            width: 70,
                            height: 70,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return const Icon(Icons.person_pin, size: 70, color: Colors.blueGrey);
                            },
                          ),
                        ),
                        const SizedBox(width: 15),
                        // Bagian Kanan: Detail Singkat (Column)
                        Expanded(
                          // Column untuk menata teks secara vertikal
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                dosen.nama,
                                style: const TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blueGrey,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                dosen.bidangKeahlian,
                                style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'NIDN: ${dosen.nidn}',
                                style: const TextStyle(fontSize: 13, fontStyle: FontStyle.italic),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.arrow_forward_ios, size: 18, color: Colors.blueGrey),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// =========================================================================
// 4. HALAMAN 2: DETAIL DOSEN
// =========================================================================

class DosenDetailScreen extends StatelessWidget {
  final Dosen dosen;

  const DosenDetailScreen({super.key, required this.dosen});

  // Fungsi pembantu untuk baris detail menggunakan Row
  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, color: Colors.teal, size: 24),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(fontSize: 15, color: Colors.black54),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Profil Dosen'),
        backgroundColor: Colors.blueGrey.shade700,
      ),
      backgroundColor: Colors.white, 
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        // Column sebagai wadah utama layout vertikal (responsif)
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            // 1. Bagian Foto dan Nama
            Center(
              child: Column(
                children: [
                  // Widget Image
                  ClipOval(
                    child: Image.asset(
                      dosen.fotoAsset,
                      width: 180,
                      height: 180,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return const Icon(Icons.account_circle, size: 180, color: Colors.blueGrey);
                      },
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Widget Text Nama Dosen
                  Text(
                    dosen.nama,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.blueGrey),
                  ),
                  // Widget Text Keahlian
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    child: Text(
                      'Bidang: ${dosen.bidangKeahlian}',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic, color: Colors.teal.shade700),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),

            const Divider(color: Colors.blueGrey, thickness: 1),
            const SizedBox(height: 20),

            // 2. Bagian Detail Informasi
            Card(
              color: Colors.blueGrey.shade50,
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'INFORMASI KONTAK & AKADEMIK',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.blueGrey),
                    ),
                    const SizedBox(height: 10),
                    // Detail menggunakan Row
                    _buildDetailRow(Icons.vpn_key, 'NIDN', dosen.nidn),
                    _buildDetailRow(Icons.email, 'Email', dosen.email),
                    _buildDetailRow(Icons.book, 'Mata Kuliah Diampu', 'Mobile Programming, Basis Data Lanjut'),
                    _buildDetailRow(Icons.school, 'Jabatan Akademik', 'Lektor Kepala'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 30),

            // 3. Widget Button Aksi
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Mencoba menghubungi ${dosen.email}...')),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal, // Warna tombol menarik
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Kirim Email ke Dosen', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
     ),
);
}
}
